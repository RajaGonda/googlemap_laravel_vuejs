<template>

    <GoogleMap/>
</template>
<script>
import GoogleMap from './../components/GoogleMap.vue';
export default {
    name: 'App',
    components: {
        GoogleMap
    },
    mounted() {
        console.log('Component mounted.')
    }
}
</script>
