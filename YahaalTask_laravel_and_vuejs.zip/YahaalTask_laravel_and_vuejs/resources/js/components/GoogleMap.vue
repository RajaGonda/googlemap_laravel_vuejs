<template>
    <div>
        <div class="mt-5">
            <!--  filters start-->
            <div class="row">
                <div class="col-2">
                    <input type="text" @keyup="search_name_fun()" class="form-control" v-model="search_name"
                           placeholder="Search Name"/>
                </div>
                <div class="col-2">

                    <select @change="search_gender_fun()" class="form-control" v-model="search_gender">
                        <option value="">All</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>

                </div>
                <div class="col-2">

                    <select @change="search_city_fun()" class="form-control" v-model="search_city">
                        <option value="">All</option>
                        <option value="51.52147256107406, -0.1277217392900015">London</option>
                        <option value="48.860811634294016, 2.3467583832126397">Paris</option>
                        <option value="38.53755313909844, -98.37745776335231">Kansas</option>
                    </select>

                </div>


            </div>
            <!--  filters End-->
        </div>
        <br>
        <!--  google map start-->
        <GmapMap
            :center='center'
            :zoom='2'
            style='width:100%;  height: 400px;'
        >

            <GmapCircle

                :center="selectCIty"
                :radius="1000"
                :visible="true"
                :fillOpacity:="1.0">
            </GmapCircle>


            <GmapMarker
                :key="index"
                v-for="(m, index) in markers"
                :position="m.position"
                :clickable="true"
                :label="m.label"
                :icon=" m.label =='M' ? 'http://maps.google.com/mapfiles/ms/icons/blue.png' : 'http://maps.google.com/mapfiles/ms/icons/pink.png'"
                @click="openWindow(m)"

            />
            <gmap-info-window
                @closeclick="window_open=false"
                :opened="window_open"
                :position="infowindow"
                :options="{
              pixelOffset: {
                width: 0,
                height: -35
              } }"
            >
                <div v-if="infowindowData">
                    name:
                    {{ infowindowData['first_name'] }}
                    {{ infowindowData['last_name'] }}
                </div>
                <div v-if="infowindowData">
                    gender:
                    {{ infowindowData['gender'] }}
                </div>
                <div v-if="infowindowData">
                    lat: {{ infowindowData['position'].lat }}, lon: {{ infowindowData['position'].lng }}
                </div>
            </gmap-info-window>
        </GmapMap>
        <!--  google map start-->
        <loader :is-visible="isLoading"></loader>
    </div>

</template>

<script>
import loader from './../components/loader.vue';

export default {
    name: 'GoogleMap',
    components: {
        loader
    },
    data() {
        return {
            timeout: null,
            isLoading: false,
            axiosInterceptor: null,
            center: {lat: 52.512942, lng: 6.089625},
            currentPlace: null,
            markers: [],
            apimarkers: [],
            places: [],
            search_name: null,
            search_gender: '',
            search_city: '',
            info_marker: null,
            infowindow: {lat: 52.512942, lng: 6.089625},
            selectCIty: {lat: 51.52147256107406, lng: -0.1277217392900015},
            window_open: false,
            infowindowData: null,

        }
    },
    mounted() {
        this.loadLocations();

    },
    methods: {

        loadLocations(search_gender = null, search_name = null) {
            // get Api call to load data
            this.isLoading = true;
            this.search_city = '';
            axios.get('/api/load-candidates?search_gender=' + search_gender + '&search_name=' + search_name)
                .then(res => {
                    this.markers = res.data.list;
                    this.apimarkers = res.data.list;
                    console.log('api data')
                    this.isLoading = false;
                }).catch(err => {
                console.log(err)
                this.isLoading = false;
            })


        },

        openWindow(m) {
            // google map marker window
            console.log(m);
            this.window_open = true
            this.infowindow = m.position;
            this.infowindowData = m;
        },

        search_gender_fun: function () {
            // api call for filter by gender
            this.loadLocations(this.search_gender, this.search_name);
        },


        degreesToRadians(degrees) {
            // for Distance calculations method
            return degrees * Math.PI / 180;
        },

        getDistanceBetweenPoints(lat1, lng1, lat2, lng2) {
            // for Distance calculations 1pont ot 2nd point
            // The radius of the planet earth in meters
            let R = 6378137;
            let dLat = this.degreesToRadians(lat2 - lat1);
            let dLong = this.degreesToRadians(lng2 - lng1);
            let a = Math.sin(dLat / 2)
                *
                Math.sin(dLat / 2)
                +
                Math.cos(this.degreesToRadians(lat1))
                *
                Math.cos(this.degreesToRadians(lat1))
                *
                Math.sin(dLong / 2)
                *
                Math.sin(dLong / 2);

            let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            let distance = R * c;

            return distance;
        },

        search_cityBy_distance: function () {
            // marker data by filter city by 2000km only

            var listLocationData = [];

            var self = this;
            var locationData = this.apimarkers;
            $.each(locationData, function (e, v) {
                var cityname = self.search_city;
                var searcllatlan = cityname.split(',');
                var latlanDostane = self.getDistanceBetweenPoints(searcllatlan[0], searcllatlan[1], v.position.lat, v.position.lng);
                latlanDostane = latlanDostane * 0.001;
                if (latlanDostane <= 2000) {
                    listLocationData.push(v);
                }
            })
            return listLocationData;
        },

        search_city_fun: function () {
            // marker data by filter by city
            this.isLoading = true;
            var cityLocations = this.search_cityBy_distance();
            this.markers = cityLocations;

            this.isLoading = false;

        },
        search_name_fun: function () {
            // filter by name from API cal data
            clearTimeout(this.timeout);

            var self = this;
            this.timeout = setTimeout(function () {
                self.loadLocations(self.search_gender, self.search_name);
            }, 700);
        },
    },
};
</script>
