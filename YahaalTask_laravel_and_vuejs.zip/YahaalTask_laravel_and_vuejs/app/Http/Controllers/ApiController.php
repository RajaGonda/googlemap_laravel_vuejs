<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function csv_to_array($filename = '', $delimiter = ',')
    {
//        csv comma delimited file format read method
        if (!file_exists($filename) || !is_readable($filename))
            return FALSE;

        $header = NULL;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== FALSE) {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
                if (!$header)
                    $header = $row;
                else
                    $data[] = (object)array_combine($header, $row);
            }
            fclose($handle);
        }
        return collect($data);
    }

    public function loadCandidates(Request $request)
    {
//      read file form mox.txt file and send data to laravel collection

        $returnData = array();
        $csv = self::csv_to_array('db_files/mock.txt');

        $key = 1;
        $csv->map(function ($q) use ($key) {
            $posi = new \stdClass();
            $posi->id = $key;
            $posi->lat = round($q->lat, 6);
            $posi->lng = round($q->lon, 6);
            unset($q->lat);
            unset($q->lon);
            $q->position = $posi;
            $q->label = ($q->gender == 'Male') ? 'M' : 'F';
            $q->icon = ($q->gender == 'Male') ? 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png' : 'http://maps.google.com/mapfiles/ms/icons/pink-dot.png';
            $key++;
        });


//        filter by gender
        if (!empty(request()->search_gender) && request()->search_gender != 'null') {
            $csv = $csv->where('gender', request()->search_gender);
        }

//        filter by first_name or  last_name
        if (!empty(request()->search_name) && request()->search_name != 'null') {
            $csv = $csv->filter(function ($user) {
                return str_contains($user->first_name, request()->search_name) || str_contains($user->last_name, request()->search_name);
            });
        }
        $returnData['list'] = $csv;
        return $returnData;

    }
}
