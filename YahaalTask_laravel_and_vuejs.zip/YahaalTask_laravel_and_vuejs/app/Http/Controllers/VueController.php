<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VueController extends Controller
{
    public function vueHome()
    {
        $returnData = array();
        return view('vuepage', $returnData);

    }
}
