<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Vue Page</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('css/app.css')); ?>" />
</head>
<body>
<div id="app">
    <app></app>

</div>

<script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\projects\gonda\jobtasks\YahaalTask\resources\views/vuepage.blade.php ENDPATH**/ ?>